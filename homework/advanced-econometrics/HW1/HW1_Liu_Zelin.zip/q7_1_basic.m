%% Advanced Econometrics HW1 - Question 7(1)
% Matrix operations; all requested answers printed in the Command Window.
A = [1,    6,    3,    -9,   12;
     97,   7,   43.2,    7,  -87;
     6.7,  5,    0,     2.6,  63;
     19,  34,  -91,   114,  37.4;
     5,   60,   26.3,  42.4, 31];
Z = [1; 0; 0; 1; 1];

% (a) 1 if and only if A(i,j) is an integer.
C = double(A == fix(A));
% (b) Select rows for which Z=1.
A_rows_Z1 = A(Z == 1, :);
% (c) Select columns for which Z=0.
A_cols_Z0 = A(:, Z == 0);

fprintf('\nQ7(1)(a) - C:\n'); disp(C);
fprintf('Q7(1)(b) - A(Z==1, :):\n'); disp(A_rows_Z1);
fprintf('Q7(1)(c) - A(:, Z==0):\n'); disp(A_cols_Z0);
