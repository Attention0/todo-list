Advanced Econometrics - Homework 1 - MATLAB Programming Q7
Liu Zelin | 2601111577

Contents:
  run_hw1.m              Run Q7(1), Q7(2) and Q7(3) in order
  q7_1_basic.m           Integer indicator and MATLAB indexing
  mydet.m                Recursive determinant expansion ALONG SECOND ROW
  q7_2_test.m            Validate mydet on the assignment's A
  q7_3_ols.m             OLS, fitted means, confidence/prediction intervals
  data1.mat              TA's data, from the provided note1.zip
  MATLAB_results.pdf     Numerical results, tables, figures, comparison to TA
  q7_3_CI_vs_PI.png      Figure from data, recreated independently for report
  q7_3_confidence_interval.png
  q7_3_coefficients.csv / q7_3_fitted_intervals.csv

RUN:
  1. Unzip into one local folder. In MATLAB switch the current folder there.
  2. Run: run_hw1
  3. MATLAB creates the 'output' folder containing CSVs and PNGs.

Notes:
  q7_3_ols.m loads only variables X and Y from data1.mat (500 observations).
  It uses betaincinv to get the exact Student-t critical value without the
  Statistics and Machine Learning Toolbox. The formulas match the TA's demo2.m.
  The numbers and report images were independently calculated in Python using
  the same OLS and interval formulas; MATLAB executable was not available in
  the preparation environment. Rerun run_hw1.m locally for MATLAB confirmation.
