%% Advanced Econometrics HW1 - Question 7(2)
% Verify second-row recursive expansion in mydet.m.
A = [1,    6,    3,    -9,   12;
     97,   7,   43.2,    7,  -87;
     6.7,  5,    0,     2.6,  63;
     19,  34,  -91,   114,  37.4;
     5,   60,   26.3,  42.4, 31];

d_my = mydet(A);
d_builtin = det(A); % Independent CHECK only; not inside mydet.m.
relative_error = abs(d_my-d_builtin)/max(1,abs(d_builtin));
fprintf('\nQ7(2): mydet(A)   = %.10f\n', d_my);
fprintf('       det(A)     = %.10f\n', d_builtin);
fprintf('       rel. error = %.3e\n', relative_error);
assert(relative_error < 1e-10,'mydet failed its numerical check.');
assert(mydet([2 1;3 4]) == 5,'Two-by-two test failed.');
assert(mydet(7) == 7,'One-by-one test failed.');
assert(mydet([1 2;2 4]) == 0,'Singular-matrix test failed.');
