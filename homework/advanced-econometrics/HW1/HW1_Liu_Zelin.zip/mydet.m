function d = mydet(A)
%MYDET Determinant using cofactor expansion along the SECOND ROW.
%   d = mydet(A) recursively expands along row 2 for each nontrivial minor.
%   MATLAB's built-in det() is NOT called in this function.

    [n,m] = size(A);
    if n ~= m
        error('mydet:NotSquare','Input matrix must be square.');
    end
    if n == 0
        d = 1;                       % Conventional det([]).
        return;
    elseif n == 1
        d = A(1,1);                  % Recursion base case.
        return;
    end

    d = 0;
    for j = 1:n
        % Minor obtained by deleting row 2 and column j.
        minor = A;
        minor(2,:) = [];
        minor(:,j) = [];
        d = d + (-1)^(2+j) * A(2,j) * mydet(minor);
    end
end
