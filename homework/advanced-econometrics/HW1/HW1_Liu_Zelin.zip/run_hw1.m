%% Advanced Econometrics Homework 1 - run Questions 7(1), 7(2), 7(3).
% In MATLAB, set Current Folder to the folder containing these .m files
% and data1.mat; then type: run_hw1
clc; close all;
q7_1_basic;
q7_2_test;
q7_3_ols;
