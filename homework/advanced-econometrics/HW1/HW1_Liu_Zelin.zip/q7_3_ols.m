%% Advanced Econometrics HW1 - Question 7(3)
% Data: TA note1/code/data1.mat (500 observations, variables X and Y).
% Direct OLS; CI for mean response and PI for NEW outcome at same x.
% All MATLAB output is placed in ./output/.
% Only core MATLAB functions are needed: the Student-t cutoff is computed
% via betaincinv, algebraically equivalent to tinv(0.975,n-2).

S = load('data1.mat','X','Y');
x = double(S.X(:));
y = double(S.Y(:));
assert(numel(x)==numel(y) && numel(x)>2, 'Check X and Y sizes.');
assert(all(isfinite(x)) && all(isfinite(y)), 'Data contain nonfinite values.');

n = numel(y);
k = 2;                            % Intercept + slope
D = [ones(n,1), x];               % Regression design matrix
assert(rank(D)==k, 'Design matrix must have full column rank.');
beta_hat = D\y;                   % Numerically stable OLS
Yb = D*beta_hat;                  % Required fitted value vector
residual = y - Yb;
df = n-k;
SSE = residual'*residual;
s2 = SSE/df;                      % Unbiased error-variance estimator
s = sqrt(s2);
V_beta = s2*((D'*D)\eye(k));
se_beta = sqrt(diag(V_beta));
t_statistics = beta_hat./se_beta;
R2 = 1 - SSE/sum((y-mean(y)).^2);

% Exact two-sided 95% Student t critical value: no statistics toolbox.
% If z = I^{-1}_{alpha}(df/2,1/2), then t_{1-alpha/2,df}
% = sqrt(df*(1-z)/z); see the regularized incomplete beta identity.
alpha = 0.05;
z = betaincinv(alpha,df/2,0.5);
tcrit = sqrt(df*(1-z)/z);

% The leverage h(x) = 1/n+(x-xbar)^2/Sxx in simple OLS.
xbar = mean(x);
Sxx = sum((x-xbar).^2);
h = 1/n + (x-xbar).^2/Sxx;
% This equals diag(D * inv(D'*D) * D'); avoid forming n-by-n matrix.

% CI estimates conditional mean E[Y|X=x] = beta0 + beta1*x.
CI_half = tcrit*s*sqrt(h);
CI_low = Yb-CI_half;
CI_high = Yb+CI_half;

% PI predicts one NEW noisy observation at the same x.
% Relative to CI, PI adds the independent new error variance, hence 1+h.
PI_half = tcrit*s*sqrt(1+h);
PI_low = Yb-PI_half;
PI_high = Yb+PI_half;

% Independent comparison with TA note1's simple-OLS formulas.
Qxx = (x-xbar)'*(x-xbar);
Qxy = (x-xbar)'*(y-mean(y));
b1_ta = Qxy/Qxx;
b0_ta = mean(y)-b1_ta*xbar;
assert(norm(beta_hat-[b0_ta;b1_ta],inf) < 1e-10, 'TA coefficient check failed.');
assert(all(PI_half >= CI_half), 'Prediction interval must contain CI.');

if ~exist('output','dir'), mkdir('output'); end
coefficient_names = {'Intercept';'X'};
coef_table = table(coefficient_names,beta_hat,se_beta,t_statistics, ...
    'VariableNames',{'Term','Estimate','StdError','tStat'});
obs = (1:n)';
fitted_table = table(obs,x,y,Yb,CI_low,CI_high,PI_low,PI_high, ...
    'VariableNames',{'Observation','X','Y','Yb','CI_Lower','CI_Upper','PI_Lower','PI_Upper'});
writetable(coef_table,fullfile('output','q7_3_coefficients.csv'));
writetable(fitted_table,fullfile('output','q7_3_fitted_intervals.csv'));
save(fullfile('output','q7_3_results.mat'), ...
    'beta_hat','se_beta','t_statistics','Yb','CI_low','CI_high', ...
    'PI_low','PI_high','s2','s','SSE','R2','h','tcrit');

fprintf('\nQ7(3): %d observations, %d d.f., t critical %.9f\n',n,df,tcrit);
fprintf('OLS intercept: %.9f (SE %.9f)\n',beta_hat(1),se_beta(1));
fprintf('OLS slope:     %.9f (SE %.9f)\n',beta_hat(2),se_beta(2));
fprintf('SSE %.9f, s^2 %.9f, RMSE %.9f, R^2 %.9f\n', SSE,s2,s,R2);
fprintf('Mean CI half-width: %.9f\n',mean(CI_half));
fprintf('Mean PI half-width: %.9f\n',mean(PI_half));
fprintf('TA benchmark check: PASSED.\n');

% Sort by x before drawing lines to avoid a zig-zag graph.
[xs,order] = sort(x);
figure('Color','white','Position',[100 100 1000 600]);
plot(x,y,'.','MarkerSize',7); hold on;
plot(xs,Yb(order),'-','LineWidth',1.8);
plot(xs,CI_low(order),'--','LineWidth',1.2);
plot(xs,CI_high(order),'--','LineWidth',1.2);
plot(xs,PI_low(order),':','LineWidth',1.5);
plot(xs,PI_high(order),':','LineWidth',1.5);
legend('Observed Y','Fitted mean','95% CI lower','95% CI upper', ...
       '95% PI lower','95% PI upper','Location','best');
xlabel('X'); ylabel('Y');
title('OLS: 95% confidence interval vs. prediction interval');
grid on; hold off;
print(gcf,fullfile('output','q7_3_CI_vs_PI.png'),'-dpng','-r180');

figure('Color','white','Position',[100 100 1000 600]);
plot(x,y,'.','MarkerSize',7); hold on;
plot(xs,Yb(order),'-','LineWidth',1.8);
plot(xs,CI_low(order),'--','LineWidth',1.4);
plot(xs,CI_high(order),'--','LineWidth',1.4);
legend('Observed Y','Fitted mean','95% CI lower','95% CI upper','Location','best');
xlabel('X'); ylabel('Y');
title('95% confidence interval for the conditional mean');
grid on; hold off;
print(gcf,fullfile('output','q7_3_confidence_interval.png'),'-dpng','-r180');
